'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { 
  Home, 
  Trophy, 
  Target, 
  Award, 
  BarChart3, 
  Menu,
  Zap,
  Bell
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface NavigationProps {
  activeTab: string
  onTabChange: (tab: string) => void
  xp: number
  notifications?: number
}

const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: Home },
  { id: 'predictions', label: 'Predictions', icon: Target },
  { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
  { id: 'rewards', label: 'Rewards', icon: Award },
  { id: 'progress', label: 'Progress', icon: BarChart3 },
]

export function Navigation({ activeTab, onTabChange, xp, notifications = 0 }: NavigationProps) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      {/* Desktop Navigation */}
      <header className="hidden lg:flex items-center justify-between p-4 glass border-b border-border sticky top-0 z-40">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-neon-orange to-neon-pink flex items-center justify-center">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-lg">PulsePlay Arena</h1>
            <p className="text-xs text-muted-foreground">Sports Engagement OS</p>
          </div>
        </div>

        {/* Nav Items */}
        <nav className="flex items-center gap-1">
          {navItems.map((item) => (
            <Button
              key={item.id}
              variant={activeTab === item.id ? 'secondary' : 'ghost'}
              onClick={() => onTabChange(item.id)}
              className={cn(
                'gap-2',
                activeTab === item.id && 'bg-primary/10 text-primary'
              )}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </Button>
          ))}
        </nav>

        {/* XP & Notifications */}
        <div className="flex items-center gap-3">
          <Badge className="bg-gradient-to-r from-primary to-neon-blue text-white px-3 py-1">
            <Zap className="w-4 h-4 mr-1" />
            {xp.toLocaleString()} XP
          </Badge>
          <Button variant="ghost" size="icon" className="relative">
            <Bell className="w-5 h-5" />
            {notifications > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-neon-orange text-white text-xs flex items-center justify-center">
                {notifications}
              </span>
            )}
          </Button>
        </div>
      </header>

      {/* Mobile Navigation */}
      <header className="lg:hidden flex items-center justify-between p-4 glass border-b border-border sticky top-0 z-40">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-neon-orange to-neon-pink flex items-center justify-center">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <h1 className="font-bold">PulsePlay</h1>
        </div>

        <div className="flex items-center gap-2">
          <Badge className="bg-primary/20 text-primary px-2 py-1 text-xs">
            <Zap className="w-3 h-3 mr-1" />
            {xp.toLocaleString()}
          </Badge>
          
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[280px] glass">
              <div className="py-4">
                <div className="flex items-center gap-2 mb-6">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-neon-orange to-neon-pink flex items-center justify-center">
                    <Zap className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="font-bold">PulsePlay Arena</h2>
                    <p className="text-xs text-muted-foreground">Sports Engagement OS</p>
                  </div>
                </div>
                
                <nav className="space-y-1">
                  {navItems.map((item) => (
                    <Button
                      key={item.id}
                      variant={activeTab === item.id ? 'secondary' : 'ghost'}
                      onClick={() => {
                        onTabChange(item.id)
                        setIsOpen(false)
                      }}
                      className={cn(
                        'w-full justify-start gap-3',
                        activeTab === item.id && 'bg-primary/10 text-primary'
                      )}
                    >
                      <item.icon className="w-5 h-5" />
                      {item.label}
                    </Button>
                  ))}
                </nav>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </header>

      {/* Mobile Bottom Navigation */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 glass border-t border-border p-2 z-40">
        <div className="flex items-center justify-around">
          {navItems.slice(0, 5).map((item) => (
            <Button
              key={item.id}
              variant="ghost"
              size="sm"
              onClick={() => onTabChange(item.id)}
              className={cn(
                'flex-col gap-0.5 h-auto py-2 px-3',
                activeTab === item.id && 'text-primary'
              )}
            >
              <item.icon className={cn(
                'w-5 h-5',
                activeTab === item.id && 'text-primary'
              )} />
              <span className="text-[10px]">{item.label}</span>
            </Button>
          ))}
        </div>
      </nav>
    </>
  )
}
