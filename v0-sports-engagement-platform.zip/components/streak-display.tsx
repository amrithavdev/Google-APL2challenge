'use client'

import { useState } from 'react'
import { Flame, Gift, AlertTriangle } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface StreakDisplayProps {
  currentStreak: number
  longestStreak: number
}

export function StreakDisplay({ currentStreak, longestStreak }: StreakDisplayProps) {
  const [showWarning] = useState(true) // Would be based on time since last activity
  
  const getStreakMultiplier = () => {
    if (currentStreak >= 30) return 3
    if (currentStreak >= 14) return 2
    if (currentStreak >= 7) return 1.5
    return 1
  }

  const multiplier = getStreakMultiplier()

  return (
    <div className="glass-card rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold flex items-center gap-2">
          <Flame className="w-5 h-5 text-neon-orange" />
          Engagement Streak
        </h3>
        {multiplier > 1 && (
          <span className="text-neon-orange text-sm font-bold animate-pulse">
            {multiplier}x XP Bonus!
          </span>
        )}
      </div>

      {/* Streak Counter */}
      <div className="text-center py-6">
        <div className="relative inline-block">
          <div className="text-6xl font-bold text-neon-orange neon-orange animate-streak-fire">
            {currentStreak}
          </div>
          <Flame className="absolute -top-2 -right-4 w-8 h-8 text-neon-orange animate-pulse" />
        </div>
        <p className="text-muted-foreground mt-2">Day Streak</p>
      </div>

      {/* Streak Progress */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Next bonus at</span>
          <span className="font-medium">
            {currentStreak < 7 ? '7 days' : currentStreak < 14 ? '14 days' : currentStreak < 30 ? '30 days' : 'Max bonus!'}
          </span>
        </div>
        
        {/* Milestone markers */}
        <div className="relative h-2 bg-secondary rounded-full overflow-hidden">
          <div 
            className="absolute inset-y-0 left-0 bg-gradient-to-r from-neon-orange to-neon-pink rounded-full transition-all duration-500"
            style={{ width: `${Math.min((currentStreak / 30) * 100, 100)}%` }}
          />
          {/* Milestone dots */}
          <div className="absolute inset-y-0 left-[23.3%] w-1 h-full bg-background" /> {/* 7 days */}
          <div className="absolute inset-y-0 left-[46.6%] w-1 h-full bg-background" /> {/* 14 days */}
        </div>
        
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>0</span>
          <span>7</span>
          <span>14</span>
          <span>30</span>
        </div>
      </div>

      {/* Warning / Reminder */}
      {showWarning && (
        <div className="mt-4 p-3 rounded-lg bg-neon-orange/10 border border-neon-orange/30">
          <div className="flex items-start gap-2">
            <AlertTriangle className="w-5 h-5 text-neon-orange shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-neon-orange">Don&apos;t break your streak!</p>
              <p className="text-xs text-muted-foreground mt-1">
                Make a prediction or react to a live moment today to maintain your {currentStreak}-day streak.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Stats */}
      <div className="mt-4 pt-4 border-t border-border flex items-center justify-between">
        <div>
          <p className="text-xs text-muted-foreground">Longest Streak</p>
          <p className="font-semibold">{longestStreak} days</p>
        </div>
        <Button size="sm" className="bg-gradient-to-r from-neon-orange to-neon-pink text-white">
          <Gift className="w-4 h-4 mr-1" />
          Claim Daily Bonus
        </Button>
      </div>
    </div>
  )
}
