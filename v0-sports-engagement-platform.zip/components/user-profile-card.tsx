'use client'

import { User, levelThresholds } from '@/lib/mock-data'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Flame, TrendingUp, Trophy, Target } from 'lucide-react'

interface UserProfileCardProps {
  user: User
}

export function UserProfileCard({ user }: UserProfileCardProps) {
  const currentLevelXP = levelThresholds[user.level - 1] || 0
  const nextLevelXP = levelThresholds[user.level] || levelThresholds[levelThresholds.length - 1]
  const xpProgress = ((user.xp - currentLevelXP) / (nextLevelXP - currentLevelXP)) * 100
  const xpToNextLevel = nextLevelXP - user.xp

  const getTierColor = (tier: User['tier']) => {
    switch (tier) {
      case 'Elite Analyst':
        return 'from-neon-orange to-neon-pink'
      case 'Active Predictor':
        return 'from-neon-blue to-neon-purple'
      default:
        return 'from-muted to-muted-foreground'
    }
  }

  return (
    <div className="glass-card rounded-xl p-6">
      <div className="flex items-start gap-4">
        {/* Avatar */}
        <div className="relative">
          <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${getTierColor(user.tier)} p-0.5`}>
            <div className="w-full h-full rounded-full bg-background flex items-center justify-center text-2xl">
              {user.avatar ? (
                <span className="text-3xl">👤</span>
              ) : (
                <span className="text-3xl">👤</span>
              )}
            </div>
          </div>
          <div className="absolute -bottom-1 -right-1 bg-primary text-primary-foreground text-xs font-bold rounded-full w-6 h-6 flex items-center justify-center">
            {user.level}
          </div>
        </div>

        {/* Info */}
        <div className="flex-1">
          <h3 className="font-bold text-lg">{user.username}</h3>
          <Badge variant="secondary" className={`bg-gradient-to-r ${getTierColor(user.tier)} text-white border-0`}>
            {user.tier}
          </Badge>
        </div>

        {/* Streak */}
        <div className="text-right">
          <div className="flex items-center gap-1 text-neon-orange">
            <Flame className="w-5 h-5" />
            <span className="font-bold text-xl">{user.streak}</span>
          </div>
          <span className="text-xs text-muted-foreground">Day Streak</span>
        </div>
      </div>

      {/* XP Progress */}
      <div className="mt-6">
        <div className="flex justify-between text-sm mb-2">
          <span className="text-muted-foreground">Level {user.level}</span>
          <span className="text-primary font-medium">{user.xp.toLocaleString()} XP</span>
        </div>
        <Progress value={xpProgress} className="h-2 bg-secondary" />
        <p className="text-xs text-muted-foreground mt-1">
          {xpToNextLevel.toLocaleString()} XP to Level {user.level + 1}
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-3 gap-4 mt-6 pt-4 border-t border-border">
        <div className="text-center">
          <div className="flex items-center justify-center gap-1 text-neon-green mb-1">
            <Target className="w-4 h-4" />
            <span className="font-bold">{user.stats.winRate}%</span>
          </div>
          <span className="text-xs text-muted-foreground">Win Rate</span>
        </div>
        <div className="text-center">
          <div className="flex items-center justify-center gap-1 text-neon-blue mb-1">
            <TrendingUp className="w-4 h-4" />
            <span className="font-bold">#{user.rank}</span>
          </div>
          <span className="text-xs text-muted-foreground">Global Rank</span>
        </div>
        <div className="text-center">
          <div className="flex items-center justify-center gap-1 text-neon-pink mb-1">
            <Trophy className="w-4 h-4" />
            <span className="font-bold">{user.stats.totalPredictions}</span>
          </div>
          <span className="text-xs text-muted-foreground">Predictions</span>
        </div>
      </div>

      {/* Badges Preview */}
      <div className="mt-4 pt-4 border-t border-border">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium">Badges</span>
          <span className="text-xs text-muted-foreground">{user.badges.filter(b => b.earnedAt).length} earned</span>
        </div>
        <div className="flex gap-2">
          {user.badges.slice(0, 4).map((badge) => (
            <div
              key={badge.id}
              className={`w-10 h-10 rounded-lg flex items-center justify-center text-lg ${
                badge.earnedAt ? 'bg-secondary' : 'bg-muted opacity-50'
              }`}
              title={badge.name}
            >
              {badge.icon}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
