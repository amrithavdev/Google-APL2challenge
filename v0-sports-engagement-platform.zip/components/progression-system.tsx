'use client'

import { User, levelThresholds, tierThresholds } from '@/lib/mock-data'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Star, ChevronRight, Sparkles } from 'lucide-react'

interface ProgressionSystemProps {
  user: User
}

export function ProgressionSystem({ user }: ProgressionSystemProps) {
  const currentLevelXP = levelThresholds[user.level - 1] || 0
  const nextLevelXP = levelThresholds[user.level] || levelThresholds[levelThresholds.length - 1]
  const xpProgress = ((user.xp - currentLevelXP) / (nextLevelXP - currentLevelXP)) * 100

  const getTierInfo = (tier: User['tier']) => {
    const info = tierThresholds[tier]
    return {
      ...info,
      color: tier === 'Elite Analyst' 
        ? 'from-neon-orange to-neon-pink' 
        : tier === 'Active Predictor'
        ? 'from-neon-blue to-neon-purple'
        : 'from-gray-400 to-gray-500',
      icon: tier === 'Elite Analyst' ? '👑' : tier === 'Active Predictor' ? '⚡' : '🎮'
    }
  }

  const currentTierInfo = getTierInfo(user.tier)
  const allTiers = Object.entries(tierThresholds) as [User['tier'], { minLevel: number; maxLevel: number }][]

  return (
    <div className="glass-card rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-semibold flex items-center gap-2">
          <Star className="w-5 h-5 text-neon-orange" />
          Progression
        </h3>
        <Badge 
          className={`bg-gradient-to-r ${currentTierInfo.color} text-white border-0`}
        >
          {currentTierInfo.icon} {user.tier}
        </Badge>
      </div>

      {/* Current Level */}
      <div className="text-center mb-6">
        <div className="relative inline-block">
          <div className={`w-24 h-24 rounded-full bg-gradient-to-br ${currentTierInfo.color} p-1`}>
            <div className="w-full h-full rounded-full bg-background flex items-center justify-center">
              <span className="text-4xl font-bold">{user.level}</span>
            </div>
          </div>
          <Sparkles className="absolute -top-1 -right-1 w-6 h-6 text-neon-orange animate-pulse" />
        </div>
        <p className="text-muted-foreground mt-2">Current Level</p>
      </div>

      {/* XP Progress */}
      <div className="mb-6">
        <div className="flex justify-between text-sm mb-2">
          <span>Level {user.level}</span>
          <span>Level {Math.min(user.level + 1, 10)}</span>
        </div>
        <Progress value={xpProgress} className="h-3" />
        <div className="flex justify-between text-xs text-muted-foreground mt-1">
          <span>{user.xp.toLocaleString()} XP</span>
          <span>{nextLevelXP.toLocaleString()} XP</span>
        </div>
      </div>

      {/* Tier Progression */}
      <div className="space-y-3">
        <h4 className="text-sm font-medium text-muted-foreground">Tier Progression</h4>
        {allTiers.map(([tier, info]) => {
          const tierInfo = getTierInfo(tier)
          const isCurrentTier = tier === user.tier
          const isUnlocked = user.level >= info.minLevel
          const levelProgress = isCurrentTier 
            ? ((user.level - info.minLevel) / (info.maxLevel - info.minLevel + 1)) * 100
            : isUnlocked ? 100 : 0

          return (
            <div 
              key={tier}
              className={`p-3 rounded-lg border transition-all ${
                isCurrentTier 
                  ? 'border-primary bg-primary/10' 
                  : isUnlocked 
                  ? 'border-border bg-secondary/50'
                  : 'border-border opacity-50'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-xl">{tierInfo.icon}</span>
                  <div>
                    <p className="font-medium text-sm">{tier}</p>
                    <p className="text-xs text-muted-foreground">
                      Levels {info.minLevel}-{info.maxLevel}
                    </p>
                  </div>
                </div>
                {isCurrentTier && (
                  <Badge variant="secondary" className="text-xs">Current</Badge>
                )}
                {!isUnlocked && (
                  <Badge variant="outline" className="text-xs">Locked</Badge>
                )}
              </div>
              <Progress value={levelProgress} className="h-1.5" />
            </div>
          )
        })}
      </div>

      {/* Level Milestones */}
      <div className="mt-6 pt-4 border-t border-border">
        <h4 className="text-sm font-medium text-muted-foreground mb-3">Level Rewards</h4>
        <div className="flex flex-wrap gap-2">
          {[1, 3, 5, 7, 10].map((level) => (
            <div
              key={level}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-sm ${
                user.level >= level
                  ? 'bg-neon-green/20 text-neon-green border border-neon-green/30'
                  : 'bg-secondary text-muted-foreground'
              }`}
            >
              <span>Lv.{level}</span>
              {user.level < level && <ChevronRight className="w-3 h-3" />}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
