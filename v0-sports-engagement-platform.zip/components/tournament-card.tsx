'use client'

import { Tournament } from '@/lib/types'
import { Badge } from '@/components/ui/badge'
import { Calendar } from 'lucide-react'

interface TournamentCardProps {
  tournament: Tournament
}

export function TournamentCard({ tournament }: TournamentCardProps) {
  const getStatusColor = () => {
    switch (tournament.status) {
      case 'active':
        return 'bg-neon-green/20 text-neon-green border-neon-green/30'
      case 'upcoming':
        return 'bg-neon-blue/20 text-neon-blue border-neon-blue/30'
      default:
        return 'bg-muted text-muted-foreground'
    }
  }

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    }).format(date)
  }

  return (
    <div className="glass-card rounded-xl p-4 hover:border-primary/50 transition-all duration-300 cursor-pointer">
      <div className="flex items-start gap-4">
        {/* Logo */}
        <div className="text-4xl">{tournament.logo}</div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-semibold truncate">{tournament.name}</h3>
            <Badge className={getStatusColor()}>
              {tournament.status === 'active' ? 'Live' : tournament.status}
            </Badge>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Calendar className="w-3 h-3" />
            <span>
              {formatDate(tournament.startDate)} - {formatDate(tournament.endDate)}
            </span>
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            {tournament.matches} matches
          </p>
        </div>
      </div>
    </div>
  )
}
