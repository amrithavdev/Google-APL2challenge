'use client'

import { LeaderboardEntry } from '@/lib/types'
import { Badge } from '@/components/ui/badge'
import { TrendingUp, TrendingDown, Minus, Crown, Medal } from 'lucide-react'
import { cn } from '@/lib/utils'

interface LeaderboardProps {
  entries: LeaderboardEntry[]
  currentUserId: string
}

export function Leaderboard({ entries, currentUserId }: LeaderboardProps) {
  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="w-5 h-5 text-yellow-400" />
      case 2:
        return <Medal className="w-5 h-5 text-gray-400" />
      case 3:
        return <Medal className="w-5 h-5 text-amber-600" />
      default:
        return <span className="w-5 h-5 flex items-center justify-center text-sm font-bold text-muted-foreground">{rank}</span>
    }
  }

  const getChangeIndicator = (change: number) => {
    if (change > 0) {
      return (
        <div className="flex items-center gap-0.5 text-neon-green text-xs">
          <TrendingUp className="w-3 h-3" />
          <span>+{change}</span>
        </div>
      )
    }
    if (change < 0) {
      return (
        <div className="flex items-center gap-0.5 text-destructive text-xs">
          <TrendingDown className="w-3 h-3" />
          <span>{change}</span>
        </div>
      )
    }
    return (
      <div className="flex items-center text-muted-foreground text-xs">
        <Minus className="w-3 h-3" />
      </div>
    )
  }

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'Elite Analyst':
        return 'bg-gradient-to-r from-neon-orange to-neon-pink text-white'
      case 'Active Predictor':
        return 'bg-gradient-to-r from-neon-blue to-neon-purple text-white'
      default:
        return 'bg-secondary text-secondary-foreground'
    }
  }

  return (
    <div className="glass-card rounded-xl overflow-hidden">
      <div className="p-4 border-b border-border">
        <h3 className="font-semibold text-lg">Global Leaderboard</h3>
        <p className="text-sm text-muted-foreground">Top predictors this season</p>
      </div>

      <div className="divide-y divide-border max-h-[500px] overflow-y-auto">
        {entries.slice(0, 25).map((entry) => {
          const isCurrentUser = entry.user.id === currentUserId

          return (
            <div
              key={entry.user.id}
              className={cn(
                'flex items-center gap-3 p-3 transition-colors',
                isCurrentUser && 'bg-primary/10 border-l-2 border-l-primary',
                entry.rank <= 3 && 'bg-gradient-to-r from-yellow-500/5 to-transparent'
              )}
            >
              {/* Rank */}
              <div className="w-8 flex justify-center">
                {getRankIcon(entry.rank)}
              </div>

              {/* Avatar */}
              <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-lg">
                👤
              </div>

              {/* User Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className={cn('font-medium truncate', isCurrentUser && 'text-primary')}>
                    {entry.user.username}
                    {isCurrentUser && <span className="text-xs ml-1">(You)</span>}
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-0.5">
                  <Badge className={cn('text-xs px-1.5 py-0', getTierColor(entry.user.tier))}>
                    {entry.user.tier}
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    Lv.{entry.user.level}
                  </span>
                </div>
              </div>

              {/* XP & Change */}
              <div className="text-right">
                <p className="font-bold text-primary">{entry.xp.toLocaleString()} XP</p>
                {getChangeIndicator(entry.change)}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
