'use client'

import { useState, useEffect } from 'react'
import { Match } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Clock, Play, ChevronRight } from 'lucide-react'

interface MatchCardProps {
  match: Match
  onPredict?: (matchId: string) => void
}

export function MatchCard({ match, onPredict }: MatchCardProps) {
  // Use state to prevent hydration mismatch with time formatting
  const [formattedTime, setFormattedTime] = useState<string>('')

  useEffect(() => {
    const formatTime = (date: Date) => {
      return new Intl.DateTimeFormat('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true,
      }).format(date)
    }
    setFormattedTime(formatTime(match.startTime))
  }, [match.startTime])

  const getStatusBadge = () => {
    switch (match.status) {
      case 'live':
        return (
          <Badge className="bg-neon-orange/20 text-neon-orange border-neon-orange/30 animate-pulse">
            <span className="w-2 h-2 rounded-full bg-neon-orange mr-1.5 animate-pulse" />
            LIVE {match.currentMinute}&apos;
          </Badge>
        )
      case 'upcoming':
        return (
          <Badge variant="secondary" className="text-muted-foreground">
            <Clock className="w-3 h-3 mr-1" />
            {formattedTime || '--:--'}
          </Badge>
        )
      case 'finished':
        return (
          <Badge variant="secondary" className="text-muted-foreground">
            FT
          </Badge>
        )
    }
  }

  return (
    <div className={`glass-card rounded-xl p-4 transition-all duration-300 hover:border-primary/50 ${
      match.status === 'live' ? 'border-neon-orange/30' : ''
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <span className="text-xs text-muted-foreground font-medium">{match.tournament}</span>
        {getStatusBadge()}
      </div>

      {/* Teams */}
      <div className="flex items-center justify-between">
        {/* Home Team */}
        <div className="flex-1 text-center">
          <div className="text-3xl mb-2">{match.homeTeam.logo}</div>
          <p className="font-semibold text-sm">{match.homeTeam.shortName}</p>
          <p className="text-xs text-muted-foreground truncate">{match.homeTeam.name}</p>
        </div>

        {/* Score / VS */}
        <div className="px-4">
          {match.status === 'upcoming' ? (
            <div className="text-center">
              <span className="text-2xl font-bold text-muted-foreground">VS</span>
            </div>
          ) : (
            <div className="text-center">
              <div className="flex items-center gap-3 text-3xl font-bold">
                <span className={match.homeScore! > match.awayScore! ? 'text-neon-green' : ''}>{match.homeScore}</span>
                <span className="text-muted-foreground">-</span>
                <span className={match.awayScore! > match.homeScore! ? 'text-neon-green' : ''}>{match.awayScore}</span>
              </div>
            </div>
          )}
        </div>

        {/* Away Team */}
        <div className="flex-1 text-center">
          <div className="text-3xl mb-2">{match.awayTeam.logo}</div>
          <p className="font-semibold text-sm">{match.awayTeam.shortName}</p>
          <p className="text-xs text-muted-foreground truncate">{match.awayTeam.name}</p>
        </div>
      </div>

      {/* Action Button */}
      {match.status !== 'finished' && (
        <div className="mt-4 pt-4 border-t border-border">
          {match.status === 'live' ? (
            <Button
              onClick={() => onPredict?.(match.id)}
              className="w-full bg-gradient-to-r from-neon-orange to-neon-pink text-white hover:opacity-90"
            >
              <Play className="w-4 h-4 mr-2" />
              Join Live
              <ChevronRight className="w-4 h-4 ml-auto" />
            </Button>
          ) : (
            <Button
              onClick={() => onPredict?.(match.id)}
              variant="secondary"
              className="w-full"
            >
              Make Prediction
              <ChevronRight className="w-4 h-4 ml-auto" />
            </Button>
          )}
        </div>
      )}
    </div>
  )
}
