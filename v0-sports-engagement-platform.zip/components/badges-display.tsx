'use client'

import { Badge, allBadges } from '@/lib/mock-data'
import { Badge as BadgeUI } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Award, Lock } from 'lucide-react'

interface BadgesDisplayProps {
  earnedBadges: Badge[]
}

export function BadgesDisplay({ earnedBadges }: BadgesDisplayProps) {
  const isEarned = (badgeId: string) => {
    return earnedBadges.some(b => b.id === badgeId && b.earnedAt)
  }

  const getBadgeProgress = (badgeId: string) => {
    const badge = earnedBadges.find(b => b.id === badgeId)
    return badge?.progress && badge?.maxProgress 
      ? { progress: badge.progress, maxProgress: badge.maxProgress }
      : null
  }

  return (
    <div className="glass-card rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold flex items-center gap-2">
          <Award className="w-5 h-5 text-neon-blue" />
          Badges & Achievements
        </h3>
        <BadgeUI variant="secondary">
          {earnedBadges.filter(b => b.earnedAt).length}/{allBadges.length}
        </BadgeUI>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {allBadges.map((badge) => {
          const earned = isEarned(badge.id)
          const progress = getBadgeProgress(badge.id)

          return (
            <div
              key={badge.id}
              className={`relative p-4 rounded-xl border transition-all duration-300 ${
                earned 
                  ? 'glass-card border-primary/30 hover:border-primary/50' 
                  : 'bg-muted/30 border-border opacity-60 hover:opacity-80'
              }`}
            >
              {/* Lock overlay for unearned */}
              {!earned && !progress && (
                <div className="absolute inset-0 flex items-center justify-center bg-background/50 rounded-xl">
                  <Lock className="w-6 h-6 text-muted-foreground" />
                </div>
              )}

              <div className="text-center">
                <div className={`text-3xl mb-2 ${earned ? '' : 'grayscale'}`}>
                  {badge.icon}
                </div>
                <h4 className="font-medium text-sm">{badge.name}</h4>
                <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                  {badge.description}
                </p>

                {/* Progress bar for in-progress badges */}
                {progress && !earned && (
                  <div className="mt-3">
                    <Progress 
                      value={(progress.progress / progress.maxProgress) * 100} 
                      className="h-1.5"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      {progress.progress}/{progress.maxProgress}
                    </p>
                  </div>
                )}

                {/* Earned indicator */}
                {earned && (
                  <BadgeUI className="mt-2 bg-neon-green/20 text-neon-green border-neon-green/30 text-xs">
                    Earned
                  </BadgeUI>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
