'use client'

import { useState, useEffect, useCallback } from 'react'
import { LiveMoment, Reaction, MomentumLevel } from '@/lib/types'
import { reactions as mockReactions } from '@/lib/mock-data'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { X, Zap, Clock, MessageSquare } from 'lucide-react'

interface LiveMomentBoostProps {
  moment: LiveMoment | null
  onClose: () => void
  onReaction: (reactionId: string, xpEarned: number) => void
}

export function LiveMomentBoost({ moment, onClose, onReaction }: LiveMomentBoostProps) {
  const [timeLeft, setTimeLeft] = useState(30)
  const [hasReacted, setHasReacted] = useState(false)
  const [selectedReaction, setSelectedReaction] = useState<string | null>(null)
  const [reactions, setReactions] = useState<Reaction[]>(mockReactions)
  const [xpAnimation, setXpAnimation] = useState<{ amount: number; visible: boolean }>({ amount: 0, visible: false })
  const [commentary, setCommentary] = useState('')
  const [momentum, setMomentum] = useState<MomentumLevel>('hype')

  // Timer countdown
  useEffect(() => {
    if (!moment) return
    
    // Reset timer when moment changes
    setTimeLeft(30)
    setHasReacted(false)
    setSelectedReaction(null)
    
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [moment])

  // Handle timer expiration
  useEffect(() => {
    if (timeLeft === 0 && moment) {
      onClose()
    }
  }, [timeLeft, moment, onClose])

  // Generate AI commentary
  useEffect(() => {
    if (!moment) return
    
    const templates = [
      `Incredible scenes! ${moment.player || 'The player'} has changed the game!`,
      `The crowd erupts! This ${moment.type} will be remembered!`,
      `What a moment! The tension is unreal right now!`,
      `This is what sports is all about! Pure emotion!`,
    ]
    
    setCommentary(templates[Math.floor(Math.random() * templates.length)])
  }, [moment])

  const handleReaction = useCallback((reaction: Reaction) => {
    if (hasReacted) return

    setHasReacted(true)
    setSelectedReaction(reaction.id)
    
    // Calculate XP (fast reactions = more XP)
    const baseXP = 25
    const timeBonus = Math.floor((timeLeft / 30) * 25) // Up to 25 bonus XP for quick reactions
    const multiplier = moment?.xpMultiplier || 1
    const totalXP = Math.floor((baseXP + timeBonus) * multiplier)

    // Show XP animation
    setXpAnimation({ amount: totalXP, visible: true })
    setTimeout(() => setXpAnimation(prev => ({ ...prev, visible: false })), 1000)

    // Update reaction count
    setReactions(prev => 
      prev.map(r => 
        r.id === reaction.id ? { ...r, count: r.count + 1 } : r
      )
    )

    onReaction(reaction.id, totalXP)
  }, [hasReacted, timeLeft, moment?.xpMultiplier, onReaction])

  if (!moment) return null

  const getMomentumColor = (level: MomentumLevel) => {
    switch (level) {
      case 'calm':
        return 'bg-neon-blue'
      case 'tense':
        return 'bg-neon-purple'
      case 'hype':
        return 'bg-neon-orange'
    }
  }

  const getMomentumEmoji = (level: MomentumLevel) => {
    switch (level) {
      case 'calm':
        return '🔵'
      case 'tense':
        return '🟣'
      case 'hype':
        return '🔴'
    }
  }

  const getMomentTypeIcon = (type: LiveMoment['type']) => {
    switch (type) {
      case 'goal':
        return '⚽'
      case 'card':
        return '🟨'
      case 'penalty':
        return '🎯'
      case 'var':
        return '📺'
      case 'substitution':
        return '🔄'
      default:
        return '⚡'
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center p-4 pointer-events-none">
      <div className="w-full max-w-md pointer-events-auto animate-slide-up">
        <div className="glass-card rounded-xl border-2 border-neon-orange/50 overflow-hidden shadow-lg shadow-neon-orange/20">
          {/* Header */}
          <div className="bg-gradient-to-r from-neon-orange to-neon-pink p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-2xl">{getMomentTypeIcon(moment.type)}</span>
                <div>
                  <h3 className="font-bold text-white text-lg">{moment.title}</h3>
                  <p className="text-white/80 text-sm">{moment.minute}&apos;</p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                className="text-white hover:bg-white/20"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Timer */}
          <div className="px-4 pt-3">
            <div className="flex items-center justify-between text-sm mb-1">
              <div className="flex items-center gap-1 text-muted-foreground">
                <Clock className="w-4 h-4" />
                <span>React now!</span>
              </div>
              <Badge variant="secondary" className="bg-neon-orange/20 text-neon-orange border-neon-orange/30">
                <Zap className="w-3 h-3 mr-1" />
                {moment.xpMultiplier}x XP
              </Badge>
            </div>
            <Progress 
              value={(timeLeft / 30) * 100} 
              className="h-2 bg-secondary"
            />
            <p className="text-xs text-center text-muted-foreground mt-1">{timeLeft}s remaining</p>
          </div>

          {/* Description */}
          <div className="px-4 py-3">
            <p className="text-sm">{moment.description}</p>
          </div>

          {/* Reactions */}
          <div className="px-4 pb-3">
            <p className="text-xs text-muted-foreground mb-2">Quick React:</p>
            <div className="grid grid-cols-6 gap-2">
              {reactions.map((reaction) => (
                <button
                  key={reaction.id}
                  onClick={() => handleReaction(reaction)}
                  disabled={hasReacted}
                  className={`flex flex-col items-center p-2 rounded-lg transition-all ${
                    selectedReaction === reaction.id
                      ? 'bg-primary/20 border-2 border-primary scale-105'
                      : hasReacted
                      ? 'bg-secondary/50 opacity-50'
                      : 'bg-secondary hover:bg-secondary/80 hover:scale-105'
                  }`}
                >
                  <span className="text-xl">{reaction.emoji}</span>
                  <span className="text-xs text-muted-foreground mt-1">
                    {reaction.count > 1000 
                      ? `${(reaction.count / 1000).toFixed(1)}k` 
                      : reaction.count}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* XP Animation */}
          {xpAnimation.visible && (
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 pointer-events-none">
              <div className="animate-xp-gain text-3xl font-bold text-neon-green">
                +{xpAnimation.amount} XP
              </div>
            </div>
          )}

          {/* Momentum Meter */}
          <div className="px-4 pb-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-muted-foreground">Momentum Meter</span>
              <span className="text-xs">
                {getMomentumEmoji(momentum)} {momentum.charAt(0).toUpperCase() + momentum.slice(1)}
              </span>
            </div>
            <div className="h-2 rounded-full bg-secondary overflow-hidden">
              <div 
                className={`h-full ${getMomentumColor(momentum)} animate-momentum-pulse`}
                style={{ width: momentum === 'hype' ? '100%' : momentum === 'tense' ? '66%' : '33%' }}
              />
            </div>
          </div>

          {/* AI Commentary */}
          <div className="px-4 pb-4">
            <div className="p-3 rounded-lg bg-secondary/50 border border-border">
              <div className="flex items-start gap-2">
                <MessageSquare className="w-4 h-4 text-primary mt-0.5" />
                <p className="text-sm italic text-muted-foreground">&quot;{commentary}&quot;</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
