'use client'

import { useState } from 'react'
import { Match } from '@/lib/types'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Trophy, Target, Users, Zap, Check } from 'lucide-react'

interface PredictionModalProps {
  match: Match | null
  open: boolean
  onClose: () => void
  onSubmit: (prediction: PredictionData) => void
}

export interface PredictionData {
  matchId: string
  type: 'winner' | 'score' | 'motm'
  value: string | { home: number; away: number }
}

const PLAYERS = [
  'Kevin De Bruyne',
  'Erling Haaland',
  'Bukayo Saka',
  'Martin Ødegaard',
  'Rodri',
  'William Saliba',
]

export function PredictionModal({ match, open, onClose, onSubmit }: PredictionModalProps) {
  const [winner, setWinner] = useState<'home' | 'away' | 'draw' | null>(null)
  const [homeScore, setHomeScore] = useState('')
  const [awayScore, setAwayScore] = useState('')
  const [selectedPlayer, setSelectedPlayer] = useState<string | null>(null)
  const [submitted, setSubmitted] = useState<string[]>([])

  if (!match) return null

  const handleSubmit = (type: 'winner' | 'score' | 'motm') => {
    let value: string | { home: number; away: number }
    
    switch (type) {
      case 'winner':
        if (!winner) return
        value = winner
        break
      case 'score':
        if (!homeScore || !awayScore) return
        value = { home: parseInt(homeScore), away: parseInt(awayScore) }
        break
      case 'motm':
        if (!selectedPlayer) return
        value = selectedPlayer
        break
    }

    onSubmit({ matchId: match.id, type, value })
    setSubmitted(prev => [...prev, type])
  }

  const isSubmitted = (type: string) => submitted.includes(type)

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="glass-card border-border max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-primary" />
            Make Your Prediction
          </DialogTitle>
          <DialogDescription className="sr-only">
            Predict the match outcome, score, or man of the match to earn XP
          </DialogDescription>
        </DialogHeader>

        {/* Match Info */}
        <div className="flex items-center justify-between p-4 bg-secondary/50 rounded-lg mb-4">
          <div className="text-center flex-1">
            <div className="text-2xl mb-1">{match.homeTeam.logo}</div>
            <p className="font-semibold text-sm">{match.homeTeam.shortName}</p>
          </div>
          <div className="px-4">
            <span className="text-xl font-bold text-muted-foreground">VS</span>
          </div>
          <div className="text-center flex-1">
            <div className="text-2xl mb-1">{match.awayTeam.logo}</div>
            <p className="font-semibold text-sm">{match.awayTeam.shortName}</p>
          </div>
        </div>

        <Tabs defaultValue="winner" className="w-full">
          <TabsList className="grid grid-cols-3 w-full">
            <TabsTrigger value="winner" className="text-xs">
              <Trophy className="w-4 h-4 mr-1" />
              Winner
            </TabsTrigger>
            <TabsTrigger value="score" className="text-xs">
              <Target className="w-4 h-4 mr-1" />
              Score
            </TabsTrigger>
            <TabsTrigger value="motm" className="text-xs">
              <Users className="w-4 h-4 mr-1" />
              MOTM
            </TabsTrigger>
          </TabsList>

          {/* Winner Prediction */}
          <TabsContent value="winner" className="space-y-4 mt-4">
            <p className="text-sm text-muted-foreground">Who will win this match?</p>
            <div className="grid grid-cols-3 gap-3">
              {[
                { key: 'home', label: match.homeTeam.shortName, icon: match.homeTeam.logo },
                { key: 'draw', label: 'Draw', icon: '🤝' },
                { key: 'away', label: match.awayTeam.shortName, icon: match.awayTeam.logo },
              ].map((option) => (
                <button
                  key={option.key}
                  onClick={() => setWinner(option.key as 'home' | 'away' | 'draw')}
                  disabled={isSubmitted('winner')}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    winner === option.key
                      ? 'border-primary bg-primary/10'
                      : 'border-border hover:border-primary/50'
                  } ${isSubmitted('winner') ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <div className="text-2xl mb-2">{option.icon}</div>
                  <p className="font-medium text-sm">{option.label}</p>
                </button>
              ))}
            </div>
            <div className="flex items-center justify-between">
              <Badge variant="secondary" className="bg-neon-blue/20 text-neon-blue border-neon-blue/30">
                <Zap className="w-3 h-3 mr-1" />
                +50 XP
              </Badge>
              <Button 
                onClick={() => handleSubmit('winner')} 
                disabled={!winner || isSubmitted('winner')}
                className="bg-gradient-to-r from-primary to-neon-blue text-white"
              >
                {isSubmitted('winner') ? (
                  <>
                    <Check className="w-4 h-4 mr-1" />
                    Submitted
                  </>
                ) : (
                  'Submit Prediction'
                )}
              </Button>
            </div>
          </TabsContent>

          {/* Score Prediction */}
          <TabsContent value="score" className="space-y-4 mt-4">
            <p className="text-sm text-muted-foreground">Predict the final score</p>
            <div className="flex items-center justify-center gap-4">
              <div className="text-center">
                <div className="text-2xl mb-2">{match.homeTeam.logo}</div>
                <Input
                  type="number"
                  min="0"
                  max="20"
                  value={homeScore}
                  onChange={(e) => setHomeScore(e.target.value)}
                  disabled={isSubmitted('score')}
                  className="w-20 text-center text-2xl font-bold"
                  placeholder="0"
                />
              </div>
              <span className="text-2xl font-bold text-muted-foreground">-</span>
              <div className="text-center">
                <div className="text-2xl mb-2">{match.awayTeam.logo}</div>
                <Input
                  type="number"
                  min="0"
                  max="20"
                  value={awayScore}
                  onChange={(e) => setAwayScore(e.target.value)}
                  disabled={isSubmitted('score')}
                  className="w-20 text-center text-2xl font-bold"
                  placeholder="0"
                />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <Badge variant="secondary" className="bg-neon-orange/20 text-neon-orange border-neon-orange/30">
                <Zap className="w-3 h-3 mr-1" />
                +100 XP
              </Badge>
              <Button 
                onClick={() => handleSubmit('score')} 
                disabled={!homeScore || !awayScore || isSubmitted('score')}
                className="bg-gradient-to-r from-neon-orange to-neon-pink text-white"
              >
                {isSubmitted('score') ? (
                  <>
                    <Check className="w-4 h-4 mr-1" />
                    Submitted
                  </>
                ) : (
                  'Submit Score'
                )}
              </Button>
            </div>
          </TabsContent>

          {/* Player of the Match */}
          <TabsContent value="motm" className="space-y-4 mt-4">
            <p className="text-sm text-muted-foreground">Who will be the player of the match?</p>
            <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto">
              {PLAYERS.map((player) => (
                <button
                  key={player}
                  onClick={() => setSelectedPlayer(player)}
                  disabled={isSubmitted('motm')}
                  className={`p-3 rounded-lg border transition-all text-left ${
                    selectedPlayer === player
                      ? 'border-primary bg-primary/10'
                      : 'border-border hover:border-primary/50'
                  } ${isSubmitted('motm') ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <p className="font-medium text-sm">{player}</p>
                </button>
              ))}
            </div>
            <div className="flex items-center justify-between">
              <Badge variant="secondary" className="bg-neon-green/20 text-neon-green border-neon-green/30">
                <Zap className="w-3 h-3 mr-1" />
                +75 XP
              </Badge>
              <Button 
                onClick={() => handleSubmit('motm')} 
                disabled={!selectedPlayer || isSubmitted('motm')}
                className="bg-gradient-to-r from-neon-green to-neon-blue text-white"
              >
                {isSubmitted('motm') ? (
                  <>
                    <Check className="w-4 h-4 mr-1" />
                    Submitted
                  </>
                ) : (
                  'Submit Pick'
                )}
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
