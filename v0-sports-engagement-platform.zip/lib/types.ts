// Types for PulsePlay Arena

export interface User {
  id: string
  username: string
  avatar: string
  xp: number
  level: number
  streak: number
  tier: 'Casual Fan' | 'Active Predictor' | 'Elite Analyst'
  badges: Badge[]
  stats: UserStats
  rank: number
  rankChange: number
}

export interface UserStats {
  totalPredictions: number
  correctPredictions: number
  winRate: number
  longestStreak: number
}

export interface Badge {
  id: string
  name: string
  description: string
  icon: string
  earnedAt?: Date
  progress?: number
  maxProgress?: number
}

export interface Match {
  id: string
  tournament: string
  homeTeam: Team
  awayTeam: Team
  status: 'upcoming' | 'live' | 'finished'
  startTime: Date
  currentMinute?: number
  homeScore?: number
  awayScore?: number
  predictions?: MatchPrediction
}

export interface Team {
  id: string
  name: string
  shortName: string
  logo: string
  color: string
}

export interface MatchPrediction {
  matchWinner?: 'home' | 'away' | 'draw'
  scorePredict?: { home: number; away: number }
  playerOfMatch?: string
}

export interface Tournament {
  id: string
  name: string
  logo: string
  matches: number
  startDate: Date
  endDate: Date
  status: 'active' | 'upcoming' | 'finished'
}

export interface LeaderboardEntry {
  rank: number
  user: User
  xp: number
  change: number
}

export interface LiveMoment {
  id: string
  type: 'goal' | 'card' | 'penalty' | 'var' | 'substitution' | 'key_moment'
  title: string
  description: string
  team?: Team
  player?: string
  minute: number
  xpMultiplier: number
  expiresAt: Date
}

export interface Reaction {
  id: string
  type: 'hype' | 'shock' | 'anger' | 'joy' | 'yes' | 'no'
  emoji: string
  count: number
}

export type MomentumLevel = 'calm' | 'tense' | 'hype'

export interface XPTransaction {
  id: string
  amount: number
  reason: string
  timestamp: Date
  multiplier?: number
}
