import { User, Match, Tournament, LeaderboardEntry, Badge, LiveMoment, Reaction } from './types'

// Current user data
export const currentUser: User = {
  id: 'user-1',
  username: 'SportsKing99',
  avatar: '/avatars/user-1.png',
  xp: 4850,
  level: 7,
  streak: 12,
  tier: 'Active Predictor',
  rank: 23,
  rankChange: 5,
  badges: [
    {
      id: 'badge-1',
      name: 'Rookie Fan',
      description: 'Made your first prediction',
      icon: '🎯',
      earnedAt: new Date('2024-01-15'),
    },
    {
      id: 'badge-2',
      name: 'Consistent Predictor',
      description: 'Maintained a 7-day streak',
      icon: '🔥',
      earnedAt: new Date('2024-02-01'),
    },
    {
      id: 'badge-3',
      name: 'Quick Reactor',
      description: 'React to 50 live moments',
      icon: '⚡',
      progress: 38,
      maxProgress: 50,
    },
  ],
  stats: {
    totalPredictions: 156,
    correctPredictions: 89,
    winRate: 57,
    longestStreak: 15,
  },
}

// All available badges
export const allBadges: Badge[] = [
  {
    id: 'badge-1',
    name: 'Rookie Fan',
    description: 'Made your first prediction',
    icon: '🎯',
  },
  {
    id: 'badge-2',
    name: 'Consistent Predictor',
    description: 'Maintained a 7-day streak',
    icon: '🔥',
  },
  {
    id: 'badge-3',
    name: 'Quick Reactor',
    description: 'React to 50 live moments',
    icon: '⚡',
  },
  {
    id: 'badge-4',
    name: 'Champion Oracle',
    description: 'Correctly predict 100 match winners',
    icon: '👑',
  },
  {
    id: 'badge-5',
    name: 'Score Master',
    description: 'Correctly predict 25 exact scores',
    icon: '🎰',
  },
  {
    id: 'badge-6',
    name: 'Streak Legend',
    description: 'Achieve a 30-day engagement streak',
    icon: '💎',
  },
]

// Teams
const teams = {
  manCity: {
    id: 'team-1',
    name: 'Manchester City',
    shortName: 'MCI',
    logo: '🔵',
    color: '#6CABDD',
  },
  arsenal: {
    id: 'team-2',
    name: 'Arsenal',
    shortName: 'ARS',
    logo: '🔴',
    color: '#EF0107',
  },
  liverpool: {
    id: 'team-3',
    name: 'Liverpool',
    shortName: 'LIV',
    logo: '🔴',
    color: '#C8102E',
  },
  chelsea: {
    id: 'team-4',
    name: 'Chelsea',
    shortName: 'CHE',
    logo: '🔵',
    color: '#034694',
  },
  realMadrid: {
    id: 'team-5',
    name: 'Real Madrid',
    shortName: 'RMA',
    logo: '⚪',
    color: '#FEBE10',
  },
  barcelona: {
    id: 'team-6',
    name: 'Barcelona',
    shortName: 'BAR',
    logo: '🔵',
    color: '#A50044',
  },
  bayernMunich: {
    id: 'team-7',
    name: 'Bayern Munich',
    shortName: 'BAY',
    logo: '🔴',
    color: '#DC052D',
  },
  psg: {
    id: 'team-8',
    name: 'Paris Saint-Germain',
    shortName: 'PSG',
    logo: '🔵',
    color: '#004170',
  },
}

// Matches
export const matches: Match[] = [
  {
    id: 'match-1',
    tournament: 'Premier League',
    homeTeam: teams.manCity,
    awayTeam: teams.arsenal,
    status: 'live',
    startTime: new Date(),
    currentMinute: 67,
    homeScore: 2,
    awayScore: 1,
  },
  {
    id: 'match-2',
    tournament: 'Champions League',
    homeTeam: teams.realMadrid,
    awayTeam: teams.bayernMunich,
    status: 'live',
    startTime: new Date(),
    currentMinute: 34,
    homeScore: 1,
    awayScore: 1,
  },
  {
    id: 'match-3',
    tournament: 'Premier League',
    homeTeam: teams.liverpool,
    awayTeam: teams.chelsea,
    status: 'upcoming',
    startTime: new Date(Date.now() + 3600000 * 2),
  },
  {
    id: 'match-4',
    tournament: 'La Liga',
    homeTeam: teams.barcelona,
    awayTeam: teams.realMadrid,
    status: 'upcoming',
    startTime: new Date(Date.now() + 3600000 * 24),
  },
  {
    id: 'match-5',
    tournament: 'Ligue 1',
    homeTeam: teams.psg,
    awayTeam: teams.bayernMunich,
    status: 'finished',
    startTime: new Date(Date.now() - 3600000 * 3),
    homeScore: 3,
    awayScore: 2,
  },
]

// Tournaments
export const tournaments: Tournament[] = [
  {
    id: 'tournament-1',
    name: 'Premier League',
    logo: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    matches: 38,
    startDate: new Date('2024-08-01'),
    endDate: new Date('2025-05-30'),
    status: 'active',
  },
  {
    id: 'tournament-2',
    name: 'Champions League',
    logo: '🏆',
    matches: 16,
    startDate: new Date('2024-09-15'),
    endDate: new Date('2025-06-01'),
    status: 'active',
  },
  {
    id: 'tournament-3',
    name: 'La Liga',
    logo: '🇪🇸',
    matches: 38,
    startDate: new Date('2024-08-15'),
    endDate: new Date('2025-05-25'),
    status: 'active',
  },
  {
    id: 'tournament-4',
    name: 'World Cup 2026',
    logo: '🌍',
    matches: 64,
    startDate: new Date('2026-06-11'),
    endDate: new Date('2026-07-19'),
    status: 'upcoming',
  },
]

// Leaderboard
export const leaderboard: LeaderboardEntry[] = [
  {
    rank: 1,
    user: {
      id: 'user-top-1',
      username: 'PredictionGod',
      avatar: '/avatars/1.png',
      xp: 12500,
      level: 10,
      streak: 45,
      tier: 'Elite Analyst',
      rank: 1,
      rankChange: 0,
      badges: [],
      stats: { totalPredictions: 450, correctPredictions: 320, winRate: 71, longestStreak: 45 },
    },
    xp: 12500,
    change: 0,
  },
  {
    rank: 2,
    user: {
      id: 'user-top-2',
      username: 'FootballWizard',
      avatar: '/avatars/2.png',
      xp: 11200,
      level: 9,
      streak: 32,
      tier: 'Elite Analyst',
      rank: 2,
      rankChange: 2,
      badges: [],
      stats: { totalPredictions: 380, correctPredictions: 260, winRate: 68, longestStreak: 38 },
    },
    xp: 11200,
    change: 2,
  },
  {
    rank: 3,
    user: {
      id: 'user-top-3',
      username: 'GoalHunter',
      avatar: '/avatars/3.png',
      xp: 10800,
      level: 9,
      streak: 28,
      tier: 'Elite Analyst',
      rank: 3,
      rankChange: -1,
      badges: [],
      stats: { totalPredictions: 350, correctPredictions: 230, winRate: 66, longestStreak: 35 },
    },
    xp: 10800,
    change: -1,
  },
  {
    rank: 4,
    user: {
      id: 'user-top-4',
      username: 'StrikerFan',
      avatar: '/avatars/4.png',
      xp: 9500,
      level: 8,
      streak: 21,
      tier: 'Active Predictor',
      rank: 4,
      rankChange: 3,
      badges: [],
      stats: { totalPredictions: 290, correctPredictions: 185, winRate: 64, longestStreak: 25 },
    },
    xp: 9500,
    change: 3,
  },
  {
    rank: 5,
    user: {
      id: 'user-top-5',
      username: 'TacticalMind',
      avatar: '/avatars/5.png',
      xp: 8900,
      level: 8,
      streak: 18,
      tier: 'Active Predictor',
      rank: 5,
      rankChange: -2,
      badges: [],
      stats: { totalPredictions: 275, correctPredictions: 170, winRate: 62, longestStreak: 22 },
    },
    xp: 8900,
    change: -2,
  },
  ...Array.from({ length: 15 }, (_, i) => ({
    rank: i + 6,
    user: {
      id: `user-${i + 6}`,
      username: `Player${i + 6}`,
      avatar: `/avatars/${i + 6}.png`,
      xp: 8000 - i * 300,
      level: Math.max(5, 8 - Math.floor(i / 3)),
      streak: Math.max(3, 15 - i),
      tier: (i < 5 ? 'Active Predictor' : 'Casual Fan') as User['tier'],
      rank: i + 6,
      rankChange: Math.floor(Math.random() * 7) - 3,
      badges: [],
      stats: {
        totalPredictions: 200 - i * 10,
        correctPredictions: 120 - i * 6,
        winRate: Math.max(45, 60 - i),
        longestStreak: 15 - Math.floor(i / 2),
      },
    },
    xp: 8000 - i * 300,
    change: Math.floor(Math.random() * 7) - 3,
  })),
]

// Insert current user at rank 23
leaderboard.splice(22, 0, {
  rank: 23,
  user: currentUser,
  xp: currentUser.xp,
  change: currentUser.rankChange,
})

// Live moments (for demo)
export const liveMoments: LiveMoment[] = [
  {
    id: 'moment-1',
    type: 'goal',
    title: 'GOAL SCORED!',
    description: 'De Bruyne scores with a brilliant strike!',
    team: teams.manCity,
    player: 'Kevin De Bruyne',
    minute: 67,
    xpMultiplier: 2,
    expiresAt: new Date(Date.now() + 30000),
  },
]

// Reactions
export const reactions: Reaction[] = [
  { id: 'r-1', type: 'hype', emoji: '🔥', count: 1234 },
  { id: 'r-2', type: 'shock', emoji: '😱', count: 856 },
  { id: 'r-3', type: 'anger', emoji: '😤', count: 423 },
  { id: 'r-4', type: 'joy', emoji: '🎉', count: 2156 },
  { id: 'r-5', type: 'yes', emoji: '👍', count: 3421 },
  { id: 'r-6', type: 'no', emoji: '👎', count: 1245 },
]

// Level thresholds
export const levelThresholds = [
  0,      // Level 1
  500,    // Level 2
  1200,   // Level 3
  2100,   // Level 4
  3200,   // Level 5
  4500,   // Level 6
  6000,   // Level 7
  7700,   // Level 8
  9600,   // Level 9
  11700,  // Level 10
]

// Tier thresholds
export const tierThresholds = {
  'Casual Fan': { minLevel: 1, maxLevel: 3 },
  'Active Predictor': { minLevel: 4, maxLevel: 7 },
  'Elite Analyst': { minLevel: 8, maxLevel: 10 },
}

// AI Commentary templates
export const aiCommentaryTemplates = [
  "The crowd goes wild! {event} - {player} showing incredible form!",
  "What a moment! {event} changes everything in this match!",
  "Tension rising! After {event}, the momentum shifts dramatically!",
  "Incredible scenes! {player} delivers when it matters most!",
  "The arena is electric! {event} has the fans on their feet!",
]
