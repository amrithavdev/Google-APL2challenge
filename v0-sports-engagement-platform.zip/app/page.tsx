'use client'

import { useState, useCallback, useEffect } from 'react'
import { Navigation } from '@/components/navigation'
import { UserProfileCard } from '@/components/user-profile-card'
import { MatchCard } from '@/components/match-card'
import { TournamentCard } from '@/components/tournament-card'
import { StreakDisplay } from '@/components/streak-display'
import { Leaderboard } from '@/components/leaderboard'
import { BadgesDisplay } from '@/components/badges-display'
import { ProgressionSystem } from '@/components/progression-system'
import { PredictionModal, PredictionData } from '@/components/prediction-modal'
import { LiveMomentBoost } from '@/components/live-moment-boost'
import { 
  currentUser, 
  matches, 
  tournaments, 
  leaderboard, 
  liveMoments,
  User
} from '@/lib/mock-data'
import { Match, LiveMoment } from '@/lib/types'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { 
  Zap, 
  Play, 
  Calendar, 
  TrendingUp,
  Sparkles
} from 'lucide-react'

export default function PulsePlayArena() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [user, setUser] = useState<User>(currentUser)
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null)
  const [predictionModalOpen, setPredictionModalOpen] = useState(false)
  const [activeMoment, setActiveMoment] = useState<LiveMoment | null>(null)
  const [xpNotification, setXpNotification] = useState<{ amount: number; visible: boolean }>({ amount: 0, visible: false })

  // Simulate live moment trigger after 5 seconds for demo
  useEffect(() => {
    const timer = setTimeout(() => {
      if (liveMoments.length > 0 && !activeMoment) {
        setActiveMoment(liveMoments[0])
      }
    }, 5000)

    return () => clearTimeout(timer)
  }, [activeMoment])

  const handlePrediction = useCallback((matchId: string) => {
    const match = matches.find(m => m.id === matchId)
    if (match) {
      setSelectedMatch(match)
      setPredictionModalOpen(true)
    }
  }, [])

  const handlePredictionSubmit = useCallback((prediction: PredictionData) => {
    // Add XP for prediction
    const xpGain = prediction.type === 'score' ? 100 : prediction.type === 'motm' ? 75 : 50
    setUser(prev => ({ ...prev, xp: prev.xp + xpGain }))
    
    // Show XP notification
    setXpNotification({ amount: xpGain, visible: true })
    setTimeout(() => setXpNotification(prev => ({ ...prev, visible: false })), 2000)
  }, [])

  const handleReaction = useCallback((reactionId: string, xpEarned: number) => {
    setUser(prev => ({ ...prev, xp: prev.xp + xpEarned }))
  }, [])

  const closeMoment = useCallback(() => {
    setActiveMoment(null)
  }, [])

  const liveMatches = matches.filter(m => m.status === 'live')
  const upcomingMatches = matches.filter(m => m.status === 'upcoming')

  return (
    <div className="min-h-screen bg-background pb-20 lg:pb-0">
      <Navigation 
        activeTab={activeTab} 
        onTabChange={setActiveTab}
        xp={user.xp}
        notifications={2}
      />

      {/* XP Notification */}
      {xpNotification.visible && (
        <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 animate-slide-up">
          <Badge className="bg-neon-green text-white text-lg px-4 py-2 shadow-lg shadow-neon-green/30">
            <Sparkles className="w-5 h-5 mr-2" />
            +{xpNotification.amount} XP
          </Badge>
        </div>
      )}

      <main className="max-w-7xl mx-auto p-4 lg:p-6">
        {/* Dashboard Tab */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            {/* Hero Section */}
            <div className="glass-card rounded-xl p-6 bg-gradient-to-r from-primary/10 to-neon-orange/10">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                <div>
                  <h2 className="text-2xl lg:text-3xl font-bold mb-2">
                    Welcome back, {user.username}! 👋
                  </h2>
                  <p className="text-muted-foreground">
                    {liveMatches.length} live matches • {upcomingMatches.length} upcoming predictions available
                  </p>
                </div>
                <Button 
                  size="lg"
                  className="bg-gradient-to-r from-neon-orange to-neon-pink text-white hover:opacity-90"
                  onClick={() => liveMatches.length > 0 && handlePrediction(liveMatches[0].id)}
                >
                  <Play className="w-5 h-5 mr-2" />
                  Join Live Match
                </Button>
              </div>
            </div>

            {/* Main Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left Column - User & Streak */}
              <div className="space-y-6">
                <UserProfileCard user={user} />
                <StreakDisplay 
                  currentStreak={user.streak} 
                  longestStreak={user.stats.longestStreak} 
                />
              </div>

              {/* Center Column - Matches */}
              <div className="lg:col-span-2 space-y-6">
                {/* Live Matches */}
                {liveMatches.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <Badge className="bg-neon-orange/20 text-neon-orange border-neon-orange/30 animate-pulse">
                        <span className="w-2 h-2 rounded-full bg-neon-orange mr-1.5" />
                        LIVE NOW
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        {liveMatches.length} matches in progress
                      </span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {liveMatches.map((match) => (
                        <MatchCard 
                          key={match.id} 
                          match={match} 
                          onPredict={handlePrediction}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {/* Upcoming Matches */}
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <Calendar className="w-5 h-5 text-muted-foreground" />
                    <h3 className="font-semibold">Upcoming Matches</h3>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {upcomingMatches.map((match) => (
                      <MatchCard 
                        key={match.id} 
                        match={match} 
                        onPredict={handlePrediction}
                      />
                    ))}
                  </div>
                </div>

                {/* Tournaments */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-muted-foreground" />
                      <h3 className="font-semibold">Active Tournaments</h3>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {tournaments.filter(t => t.status === 'active').slice(0, 4).map((tournament) => (
                      <TournamentCard key={tournament.id} tournament={tournament} />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Predictions Tab */}
        {activeTab === 'predictions' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">Predictions</h2>
                <p className="text-muted-foreground">Make predictions and earn XP</p>
              </div>
              <Badge variant="secondary" className="bg-neon-blue/20 text-neon-blue border-neon-blue/30">
                <Zap className="w-4 h-4 mr-1" />
                +50-100 XP per prediction
              </Badge>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {matches.filter(m => m.status !== 'finished').map((match) => (
                <MatchCard 
                  key={match.id} 
                  match={match} 
                  onPredict={handlePrediction}
                />
              ))}
            </div>
          </div>
        )}

        {/* Leaderboard Tab */}
        {activeTab === 'leaderboard' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold">Global Leaderboard</h2>
              <p className="text-muted-foreground">Compete with fans worldwide</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Leaderboard entries={leaderboard} currentUserId={user.id} />
              </div>
              <div>
                <UserProfileCard user={user} />
              </div>
            </div>
          </div>
        )}

        {/* Rewards Tab */}
        {activeTab === 'rewards' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold">Rewards & Badges</h2>
              <p className="text-muted-foreground">Track your achievements</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <BadgesDisplay earnedBadges={user.badges} />
              </div>
              <div>
                <StreakDisplay 
                  currentStreak={user.streak} 
                  longestStreak={user.stats.longestStreak} 
                />
              </div>
            </div>
          </div>
        )}

        {/* Progress Tab */}
        {activeTab === 'progress' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold">Your Progress</h2>
              <p className="text-muted-foreground">Level up and unlock rewards</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ProgressionSystem user={user} />
              <UserProfileCard user={user} />
            </div>
          </div>
        )}
      </main>

      {/* Prediction Modal */}
      <PredictionModal
        match={selectedMatch}
        open={predictionModalOpen}
        onClose={() => setPredictionModalOpen(false)}
        onSubmit={handlePredictionSubmit}
      />

      {/* Live Moment Boost */}
      <LiveMomentBoost
        moment={activeMoment}
        onClose={closeMoment}
        onReaction={handleReaction}
      />
    </div>
  )
}
